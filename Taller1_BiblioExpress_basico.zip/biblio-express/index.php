<?php
include("conexion.php");

$sql = "SELECT * FROM libro";
$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi biblioteca</title>
</head>
<body>

<h1>Mi biblioteca</h1>

<a href="crear.php">Agregar libro</a>
<br><br>

<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Titulo</th>
        <th>ISBN</th>
        <th>Año</th>
        <th>Idioma</th>
        <th>Paginas</th>
        <th>Acciones</th>
    </tr>

    <?php while ($libro = $resultado->fetch(PDO::FETCH_ASSOC)) { ?>
    <tr>
        <td><?php echo $libro["id_libro"]; ?></td>
        <td><?php echo htmlspecialchars($libro["titulo"]); ?></td>
        <td><?php echo htmlspecialchars($libro["isbn"]); ?></td>
        <td><?php echo $libro["ano_publicacion"]; ?></td>
        <td><?php echo htmlspecialchars($libro["idioma"]); ?></td>
        <td><?php echo $libro["numero_paginas"]; ?></td>
        <td>
            <a href="editar.php?id=<?php echo $libro["id_libro"]; ?>">Editar</a>

            <form action="eliminar.php" method="POST" style="display:inline;">
                <input type="hidden" name="id" value="<?php echo $libro["id_libro"]; ?>">
                <button type="submit" onclick="return confirm('¿Desea eliminar este libro?');">
                    Eliminar
                </button>
            </form>
        </td>
    </tr>
    <?php } ?>
</table>

</body>
</html>
