<?php
try {
    $conexion = new PDO(
        "mysql:host=localhost;dbname=biblio_express;charset=utf8mb4",
        "root",
        ""
    );

    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $error) {
    die("No se pudo conectar con la base de datos.");
}
?>
