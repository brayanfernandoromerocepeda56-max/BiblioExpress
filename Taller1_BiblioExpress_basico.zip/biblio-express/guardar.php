<?php
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $titulo = trim($_POST["titulo"]);
    $isbn = trim($_POST["isbn"]);
    $ano = $_POST["ano"];
    $idioma = trim($_POST["idioma"]);
    $paginas = $_POST["paginas"];

    if ($titulo == "" || $isbn == "" || $idioma == "" ||
        !is_numeric($ano) || $ano <= 1500 ||
        !is_numeric($paginas) || $paginas <= 0) {
        die("Revise los datos. Hay campos vacios o numeros incorrectos.");
    }

    $sql = "INSERT INTO libro
            (titulo, isbn, ano_publicacion, idioma, numero_paginas)
            VALUES (?, ?, ?, ?, ?)";

    $consulta = $conexion->prepare($sql);
    $consulta->execute([$titulo, $isbn, $ano, $idioma, $paginas]);

    header("Location: index.php");
    exit;
}
?>
