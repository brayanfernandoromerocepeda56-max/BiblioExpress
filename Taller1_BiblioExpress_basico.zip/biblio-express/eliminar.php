<?php
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $id = isset($_POST["id"]) ? (int) $_POST["id"] : 0;

    if ($id <= 0) {
        die("ID incorrecto.");
    }

    $sql = "DELETE FROM libro WHERE id_libro = ?";
    $consulta = $conexion->prepare($sql);
    $consulta->execute([$id]);

    header("Location: index.php");
    exit;
}

echo "Solicitud incorrecta.";
?>
