<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar libro</title>
</head>
<body>

<h1>Agregar un libro</h1>

<form action="guardar.php" method="POST">

    Titulo:<br>
    <input type="text" name="titulo" required maxlength="150">
    <br><br>

    ISBN:<br>
    <input type="text" name="isbn" required maxlength="50">
    <br><br>

    Año de publicacion:<br>
    <input type="number" name="ano" min="1501" required>
    <br><br>

    Idioma:<br>
    <input type="text" name="idioma" required maxlength="50">
    <br><br>

    Numero de paginas:<br>
    <input type="number" name="paginas" min="1" required>
    <br><br>

    <button type="submit">Guardar</button>
</form>

<br>
<a href="index.php">Volver</a>

</body>
</html>
