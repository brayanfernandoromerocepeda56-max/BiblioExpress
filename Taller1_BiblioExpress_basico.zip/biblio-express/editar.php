<?php
include("conexion.php");

$id = isset($_GET["id"]) ? (int) $_GET["id"] : 0;

if ($id <= 0) {
    die("ID incorrecto.");
}

$sql = "SELECT * FROM libro WHERE id_libro = ?";
$consulta = $conexion->prepare($sql);
$consulta->execute([$id]);
$libro = $consulta->fetch(PDO::FETCH_ASSOC);

if (!$libro) {
    die("No se encontro el libro.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $titulo = trim($_POST["titulo"]);
    $isbn = trim($_POST["isbn"]);
    $ano = $_POST["ano"];
    $idioma = trim($_POST["idioma"]);
    $paginas = $_POST["paginas"];

    if ($titulo == "" || $isbn == "" || $idioma == "" ||
        !is_numeric($ano) || $ano <= 1500 ||
        !is_numeric($paginas) || $paginas <= 0) {
        die("Revise los datos. Hay campos vacios o numeros incorrectos.");
    }

    $sql = "UPDATE libro SET titulo = ?, isbn = ?, ano_publicacion = ?,
            idioma = ?, numero_paginas = ? WHERE id_libro = ?";

    $consulta = $conexion->prepare($sql);
    $consulta->execute([$titulo, $isbn, $ano, $idioma, $paginas, $id]);

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar libro</title>
</head>
<body>

<h1>Editar libro</h1>

<form method="POST">
    Titulo:<br>
    <input type="text" name="titulo"
        value="<?php echo htmlspecialchars($libro["titulo"]); ?>" required maxlength="150">
    <br><br>

    ISBN:<br>
    <input type="text" name="isbn"
        value="<?php echo htmlspecialchars($libro["isbn"]); ?>" required maxlength="50">
    <br><br>

    Año de publicacion:<br>
    <input type="number" name="ano"
        value="<?php echo $libro["ano_publicacion"]; ?>" min="1501" required>
    <br><br>

    Idioma:<br>
    <input type="text" name="idioma"
        value="<?php echo htmlspecialchars($libro["idioma"]); ?>" required maxlength="50">
    <br><br>

    Numero de paginas:<br>
    <input type="number" name="paginas"
        value="<?php echo $libro["numero_paginas"]; ?>" min="1" required>
    <br><br>

    <button type="submit">Actualizar</button>
</form>

<br>
<a href="index.php">Volver</a>

</body>
</html>
